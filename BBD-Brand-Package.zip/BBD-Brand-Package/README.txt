BBD Air Systems brand package

01-Logos
  Stacked (primary), Horizontal, Wordmark, Brandmark (bulldog solid + outline), Icon
  Colourways: full (light backgrounds), reverse (dark backgrounds), black, white
  SVG = vector master for print and web. PNG = transparent, 4x size.
  Icon: app icon, square icons, favicons at 32, 180 and 512 px.

02-Business-Cards
  BBD-business-card-PRINT-3.5x2-with-bleed.pdf: 2 pages (front, back), 3.75 x 2.25 in with 0.125 in bleed.
  Trim to 3.5 x 2 in. QR code on the back saves Les's contact to a phone (vCard).

03-Website
  index.html: single self-contained file. Drop into the bbd-air-systems GitHub repo as index.html.
  Quote form opens the visitor's email app addressed to les@bbdair.com.

04-Brand-Guide
  BBD-brand-guide.pdf: idea, logo set, clear space, minimum sizes, colour, type, do and don't.

Colours: primary Shop ink #121212; accents Brake red #D22F22 and White #FFFFFF (logo, cards), page grey #F2F2F2; support Galvanized #C9CBCC
Type: Chakra Petch Bold for headlines and labels (45 degree corners), Archivo Regular for body. Both free on Google Fonts.
